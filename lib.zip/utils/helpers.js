export function calculatePayBreakdown({ start, end, date, isHoliday, isSunday }) {
  const baseRate = 15.10;
  const unsocialRate = 18.88;
  const sundayRate = 22.65;
  const holidayRate = 30.20;

  const toDecimalHours = (t) => {
    const [h, m] = t.split(':').map(Number);
    return h + m / 60;
  };

  const startHr = toDecimalHours(start);
  const endHr = toDecimalHours(end);

  let totalHours = endHr - startHr;
  if (totalHours <= 0) return { total: 0, totalHours: 0 };

  const breakHours = totalHours > 6 ? 1 : 0; // as per our latest agreed policy

  const breakdown = {
    holidayHours: 0,
    holidayRate,
    holidayPay: 0,
    sundayHours: 0,
    sundayRate,
    sundayPay: 0,
    unsocialHours: 0,
    unsocialRate,
    unsocialPay: 0,
    baseHours: 0,
    baseRate,
    basePay: 0,
    total: 0,
    breakHours,
    totalHours: totalHours - breakHours
  };

  if (isHoliday) {
    breakdown.holidayHours = totalHours;
    breakdown.holidayPay = breakdown.totalHours * holidayRate;
    breakdown.total = breakdown.holidayPay;
    return breakdown;
  }

  if (isSunday) {
    breakdown.sundayHours = totalHours;
    breakdown.sundayPay = breakdown.totalHours * sundayRate;
    breakdown.total = breakdown.sundayPay;
    return breakdown;
  }

  // Weekday breakdown
  const earlyUnsocial = Math.max(0, Math.min(endHr, 8) - Math.max(startHr, 0));
  const lateUnsocial = Math.max(0, Math.min(endHr, 24) - Math.max(startHr, 20));
  const unsocialHours = earlyUnsocial + lateUnsocial;

  const baseHours = totalHours - unsocialHours;
  const basePayHours = Math.max(0, baseHours - breakHours);

  breakdown.unsocialHours = unsocialHours;
  breakdown.unsocialPay = unsocialHours * unsocialRate;
  breakdown.baseHours = baseHours;
  breakdown.basePay = basePayHours * baseRate;
  breakdown.total = breakdown.basePay + breakdown.unsocialPay;

  return breakdown;
}
