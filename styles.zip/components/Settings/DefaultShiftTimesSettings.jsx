// components/Settings/DefaultShiftTimesSettings.jsx
import React from 'react';

export default function DefaultShiftTimesSettings() {
  return (
    <section>
      <h2>Default Shift Times</h2>
      {/* your inputs to set default start/end here */}
      <p>(Coming soon…)</p>
    </section>
  );
}
