import React, { useState } from 'react';
import { useRouter }    from 'next/router';
import PublicHolidaysSettings   from '../../components/Settings/PublicHolidaysSettings';
import DefaultShiftTimesSettings from '../../components/Settings/DefaultShiftTimesSettings';
import MobileNav                 from '../../components/Settings/MobileNav';
import styles                    from '../../styles/Settings.module.css';

export default function Settings() {
  const router = useRouter();
  const [tab, setTab] = useState('holidays');

  return (
    <main className={styles.page}>
      <header className={styles.title}>
        <h1>⚙️ Settings</h1>
      </header>

      {/* Desktop tabs */}
      <div className={styles.tabs}>
        <button
          className={tab==='holidays' ? styles.activeTab : styles.tab}
          onClick={() => setTab('holidays')}
        >
          Public Holidays
        </button>
        <button
          className={tab==='defaults' ? styles.activeTab : styles.tab}
          onClick={() => setTab('defaults')}
        >
          Default Shift Times
        </button>
        <button
          className={styles.homeButton}
          onClick={() => router.push('/')}
        >
          Home
        </button>
      </div>

      {/* Mobile swipeable nav */}
      <MobileNav tab={tab} setTab={setTab} />

      {/* Content */}
      <section className={styles.content}>
        {tab === 'holidays'
          ? <PublicHolidaysSettings />
          : <DefaultShiftTimesSettings />
        }
      </section>
    </main>
  );
}
